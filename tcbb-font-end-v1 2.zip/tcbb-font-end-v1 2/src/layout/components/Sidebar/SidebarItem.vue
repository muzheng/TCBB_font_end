<template>
  <!--当子集大于 0 显示带有子集的element 否则执行第二个控件  :index="route.path"绑定一个路径-->
  <el-sub-menu v-if="route.children.length > 0" :index="route.path">
    <!--渲染标题和图标-->
    <template #title>
      <menu-item :title="route.meta.title" :icon="route.meta.icon"></menu-item>
    </template>
    <!--循环渲染-->
    <sidebar-item v-for="item in route.children" :key="item.path" :route="item"></sidebar-item>
  </el-sub-menu>
  <el-menu-item v-else :index="route.path">
    <menu-item :title="route.meta.title" :icon="route.meta.icon"></menu-item>
  </el-menu-item>
</template>

<script setup>
import MenuItem from './MenuItem'
// defineProps通信组件
import { defineProps } from 'vue'
defineProps({
  route: {
    type: Object,
    required: true
  }
})
</script>

<style scoped>

</style>
