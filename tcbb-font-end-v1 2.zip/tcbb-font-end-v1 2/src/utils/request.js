/**
 * 导入axios模块
 * req res数据拦截
 */
import axios from 'axios'
import { ElMessage } from 'element-plus'
// 从store 中获得token 信息
import store from '@/store'
import { isCheckTimeout } from '@/utils/auth'
/**
 * 创建一个axios实例，名称为service
 * @type {AxiosInstance}
 */

const service = axios.create({
  baseURL: 'http://localhost:3000/',
  timeout: 50000
})

/**
 * 响应拦截器
 * 对响应数据做点什么
 * 对响应错误做点什么
 * 注意： { success, message, data }跟后端返回值要一致
 * 在这里进行用户登录验证
 */

service.interceptors.response.use(
  response => {
    console.log(response.data)
    console.log('test')
    const { success, message, data } = response.data
    // 判断当前请求是否成功
    if (success) {
      console.log(data)
      return data
    } else {
      // 失败（请求成功， 业务失败），消息提示
      console.log('失败')
      ElMessage.error(message)
      return Promise.reject(new Error(message))
    }
  },
  // 请求失败
  error => {
    ElMessage.error(error.message)
    return Promise.reject(error)
  })

/**
 * 请求拦截器，自动将token进行注入，节省获取token的操作
 * 从store 中获得token 然后进行注入
 * 主动介入token 失效
 */
service.interceptors.request.use(
  config => {
    // 统一注入token
    console.log(store.getters.token)
    if (store.getters.token) {
      // 如果存在token ，注入token
      // 进行一次拦截判断,时间是否为超时
      if (isCheckTimeout()) {
        // 返回true 超时，退出
        store.dispatch('user/logout')
        return Promise.reject(new Error('token 失效'))
      }
      config.headers.Authorization = `Bearer ${store.getters.token}`
    }
    console.log(config)
    return config
  },
  error => {
    return Promise.reject(error)
  }
)
/**
 * 导出service服务
 */
export default service
