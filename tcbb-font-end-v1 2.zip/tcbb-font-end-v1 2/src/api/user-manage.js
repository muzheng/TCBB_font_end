/**
 * 导入封装好的axios
 * 重新封装的axios已经进行过滤处理
 */
import request from '@/utils/request'

/**
 * 获得用户列表
 * @param data
 * @returns {*}
 */
export const getUserManageList = data => {
  console.log(data)
  return request({
    url: '/userManage/userList',
    method: 'POST',
    data
  })
}

/**
 * check 要创建的学员信息是否已经创建  已学员卡号为基准
 */
export const checkNewUserCard = data => {
  console.log(data)
  return request({
    url: '/userManage/checkNewUserCard',
    method: 'POST',
    data
  })
}

/**
 * 创建新学员信息
 */
export const createUser = data => {
  console.log(data)
  return request({
    url: '/userManage/createUser',
    method: 'POST',
    data
  })
}

/**
 * 通过 ID 获得学员信息
 */
export const fetchById = data => {
  console.log(data)
  return request({
    url: '/userManage/fetchById',
    method: 'POST',
    data
  })
}

/**
 * 更新 学员信息
 */
export const updateUserMessage = data => {
  console.log(data)
  return request({
    url: '/userManage/updateUserMessage',
    method: 'POST',
    data
  })
}

/**
 * 删除学员信息
 */
export const deleteUser = data => {
  console.log(data)
  return request({
    url: '/userManage/deleteUser',
    method: 'POST',
    data
  })
}

/**
 * 通过卡号获得学员信息
 */
export const fetchByCardID = data => {
  console.log(data)
  return request({
    url: '/userManage/fetchByCardId',
    method: 'POST',
    data
  })
}

/**
 * 通过手机号获得学员信息
 */
export const fetchByTel = data => {
  console.log(data)
  return request({
    url: '/userManage/fetchByTel',
    method: 'POST',
    data
  })
}

/**
 * 通过学员姓名获得学员信息
 */
export const fetchByName = data => {
  console.log(data)
  return request({
    url: '/userManage/fetchByName',
    method: 'POST',
    data
  })
}

/**
 * 通过id获得学员信息
 */
export const fetchByID = data => {
  console.log(data)
  return request({
    url: '/userManage/fetchByID',
    method: 'POST',
    data
  })
}

/**
 *  更新用户基本信息
 */
export const updateUserBaseInfo = data => {
  console.log(data)
  return request({
    url: '/userManage/updateUserBaseInfo',
    method: 'POST',
    data
  })
}
