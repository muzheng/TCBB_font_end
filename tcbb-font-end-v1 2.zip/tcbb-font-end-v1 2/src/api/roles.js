/**
 * 此项目作废
 */
import request from '@/utils/request'
/**
 * check roles是否已经存在
 */
export const checkRole = data => {
  console.log(data)
  return request({
    url: '/roles/checkRole',
    method: 'POST',
    data
  })
}
/**
 * create new roles
 */
export const createRole = data => {
  return request({
    url: '/roles/createRole',
    method: 'POST',
    data
  })
}
/**
 * edit roles
 */
export const editRole = data => {
  return request({
    url: '/roles/editRole',
    method: 'GET',
    data
  })
}
/**
 * remove roles
 */
export const removeRole = data => {
  return request({
    url: '/roles/removeRole',
    method: 'GET',
    data
  })
}

/**
 * 获得role列表
 */
export const roleList = data => {
  return request({
    url: '/roles/roleList',
    method: 'GET',
    data
  })
}
