<template>
<div class="">
  <el-card>
    <el-button type="primary" @click="onCreateRoles">创建</el-button>
  </el-card>
</div>
  <div>
    <el-card>
      <!--border style="width: 100%" 指定边框为100%-->
      <el-table  v-loading = 'loading' :data="allRoles.result" border style="width: 100%">
        <el-table-column type="index"  label="序号" width="120"></el-table-column>
        <el-table-column  label="名称" prop="title" ></el-table-column>
        <el-table-column  label="描述" prop="describe"></el-table-column>
        <el-table-column  label="操作" width="200">
          <el-button type="primary" size="mini">编辑</el-button>
          <el-button type="danger" size="mini">删除</el-button>
        </el-table-column>
      </el-table>
      <el-pagination></el-pagination>
    </el-card>
  </div>
  <create-roles v-model= "createRoleDialogVisible"></create-roles>
</template>

<script setup>
import { ref, watch } from 'vue'
import { roleList } from '@/api/roles'
import CreateRoles from './components/CreateRoles'

const loading = ref(false)
const createRoleDialogVisible = ref(false)
const onCreateRoles = () => {
  createRoleDialogVisible.value = true
  console.log('create')
}

watch(createRoleDialogVisible, val => {
  console.log(val)
  if (val === false) {
    getRoleList()
  }
})

const allRoles = ref([])
const getRoleList = async () => {
  loading.value = true
  allRoles.value = await roleList()
  loading.value = false
}
getRoleList()

console.log(getRoleList())
console.log(allRoles)
</script>

<style lang="scss" scoped>

</style>
