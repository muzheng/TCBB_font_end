<template>
<div class="">
  <pan-thumb/>
  个人信息介绍</div>
</template>

<script setup>
import {} from 'vue'
import PanThumb from '@/components/PanThumb/index.vue'
</script>

<style lang="scss" scoped>

</style>
