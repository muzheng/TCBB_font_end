<template>
  <div class="my-container">
    <el-row>
      <el-col :span="6">
        <profile-card class="profile-card">
          <pan-thumb/>
        </profile-card>
      </el-col>
      <el-col :span="18">
        <el-card>
          <el-tabs v-model="activeName">
            <el-tab-pane label="基本信息" name="base-information">
              <base-information/>
            </el-tab-pane>
            <el-tab-pane label="消息" name="message">
              <message/>
            </el-tab-pane>
            <el-tab-pane label="历史记录" name="history">
              <profile-history/>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import ProfileCard from './components/profileCard.vue'
import BaseInformation from './components/baseInformation.vue'
import Message from './components/message.vue'
import ProfileHistory from './components/profileHistory.vue'

import { ref } from 'vue'

const activeName = ref('base-information')
</script>

<style lang="scss" scoped>
.my-container {
  .user-card {
    margin-right: 20px;
  }
}

</style>
