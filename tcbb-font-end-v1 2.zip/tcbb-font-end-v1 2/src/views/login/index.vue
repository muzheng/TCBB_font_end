<!---el-form 表单组件 由输入框、选择器、单选框、多选框等控件组成，用以收集、校验、提交数据----->
<!--placeholder:  属性提供可描述输入字段预期值的提示信息(hint) -->
<!--name: 此el-input的一个实例的名字-->
<!--type： 此el-input的输入类型-->
<!--ref： 相当于一个插槽-->
<template>
  <div class="background">
  </div>
<div class="login-container">
  <el-form class="login-form" ref="loginFromRef" :model="loginFrom" :rules="loginRules">
    <div class="title-container">
      <h3 class="name">{{$t('msg.login.name')}}</h3>
      <h5 class="title">{{$t('msg.login.title')}}</h5>
      <lang-select class="lang-select" effect="light"></lang-select>
    </div>
    <!--username-->
    <el-form-item prop="username">
        <span class="svg-container">
          <svg-icon icon="user" />
        </span>
      <el-input
        placeholder="请输入手机号"
        name="username"
        type="text"
        v-model="loginFrom.username"
      />
    </el-form-item>
    <!--password-->
    <el-form-item prop="password">
      <span class="svg-container">
          <svg-icon icon="password"></svg-icon>
      </span>
      <el-input placeholder="请输入密码" name="password" :type="passwordType" v-model="loginFrom.password"></el-input>
      <span class="show-pwd">
        <span class="svg-container" @click="onChangePwdType">
          <!--:icon="passwordType === 'password'? 'eye' : 'eye-open'"为html里面的语法，类似与if else-->
          <svg-icon :icon="passwordType === 'password'? 'eye' : 'eye-open'"></svg-icon>
      </span>
      </span>
    </el-form-item>
    <!--登录按钮-->
    <!--margin-bottom: 设置元素的下外边距 规定以具体单位计的下外边距值，比如像素、厘米等。默认值是 0px-->
    <el-button type="primary" style="width: 100%; margin-bottom: 30px" @click="handlerLogin" :loading="loading">{{$t('msg.login.loginBtn')}}</el-button>
  </el-form>
</div>
</template>

<script setup>
// vue3中导入的组件可以直接使用
// 使用el-icon控件包裹住avatar控件
// import { Avatar } from '@element-plus/icons'
// import SvgIcon from '@/components/SvgIcon/index.vue'
import LangSelect from '@/components/langSelect'
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRouter } from 'vue-router'
// 导入密码校验函数
import { validatePassword } from './rules'
// 导入useStore 从vuex中
import { useStore } from 'vuex'
// 数据源
const loginFrom = ref({
  username: '',
  password: ''
})
// 验证规则
const i18n = useI18n()
/**
 * required: true,要执行表单验证
 * trigger: 'blur',失去焦点
 * message: '用户名为必填项' 显示出要提示的信息
 *  validator: 自定义规则，一般为一个校验函数
 * @type {Ref<UnwrapRef<{username: *[]}>>}
 */
const loginRules = ref({
  username: [
    {
      required: true,
      trigger: 'blur',
      message: i18n.t('msg.login.usernameRule')
    }
  ],
  password: [
    {
      required: true,
      trigger: 'blur',
      validator: validatePassword()
    }
  ]
})

// 处理密码框文本显示
const passwordType = ref('password')
// template中绑定的方法，直接声明即可
// 使用 ref 声明的数据，在script中使用，需要加value来获取具体的值
// 在template 中使用的时候，不需要加value
const onChangePwdType = () => {
  // 当passwordType 的值为 password 的时候，改为text
  if (passwordType.value === 'password') {
    passwordType.value = 'text'
  } else {
    passwordType.value = 'password'
  }
}

// 处理登录
const loading = ref(false)
// 得到vuex的一个实例 store
const store = useStore()
const router = useRouter()
// loginFormRef 会自动到templete中去找loginFromRef
const loginFromRef = ref(null)
const handlerLogin = () => {
  // 1进行表单校验
  // 获取登录实例
  console.log(loginFromRef.value)
  loginFromRef.value.validate(valid => {
    if (!valid) return
    loading.value = true
    // 触发store中 login的actions
    console.log(loginFrom)
    store.dispatch('user/login', loginFrom.value)
      .then(() => {
        loading.value = false
        // TODO 登陆后处理
        // 登录后操作
        router.push('/')
      })
      .catch(err => {
        console.log(err)
        loading.value = false
      })
  })
  // 2出发登录动作
  // 3j进行登陆后处理
}

</script>

<style lang="scss" scoped>
$bg: #2d3a4b;
$dark_gray: #889aa4;
$light_gray: #eee;
$cursor: #fff;

.background{
  background: url("../assets/bg.jpg");
  background-size:100% 100%;
  // position: fixed;
  width:100%;
  height:100%;  /**宽高100%是为了图片铺满屏幕 */
  z-index:-1;
 position: absolute;
}

.login-container {
  min-height: 100%;
  width: 100%;
 // background-color: $bg;
  overflow: hidden;

  .login-form {
    position: relative;
    width: 520px;
    max-width: 100%;
    padding: 160px 35px 0;
    margin: 0 auto;
    overflow: hidden;

    ::v-deep .el-form-item {
      border: 1px solid rgba(255, 255, 255, 0.1);
      background: rgba(0, 0, 0, 0.1);
      border-radius: 5px;
      color: #454545;
    }

    ::v-deep .el-input {
      display: inline-block;
      height: 47px;
      width: 85%;

      input {
        background: transparent;
        border: 1px;
        -webkit-appearance: none;
        border-radius: 1px;
        padding: 12px 5px 12px 15px;
        color: $light_gray;
        height: 47px;
        caret-color: $cursor;
      }
    }
  }

  .svg-container {
    padding: 6px 5px 6px 15px;
    color: $dark_gray;
    vertical-align: middle;
    display: inline-block;
  }

  .title-container {
    position: relative;
    .name {
      font-size: 40px;
      color: $light_gray;
      margin: 0px auto 40px auto;
      text-align: center;
      font-weight: bold;
    }

    .title {
      font-size: 30px;
      color: $light_gray;
      margin: 0px auto 40px auto;
      text-align: center;
      font-weight: bold;
    }
    ::v-deep .lang-select {
      position: absolute;
      top: 8px;
      right: 0;
      background-color: white;
      font-size: 22px;
      padding: 4px;
      border-radius: 4px;
      cursor: pointer;
    }
  }
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 7px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
    user-select: none;
  }
}
</style>
