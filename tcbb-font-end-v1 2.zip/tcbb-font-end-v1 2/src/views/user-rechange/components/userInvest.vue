<template>
  <el-dialog title="学员充值" width="40%" :model-value="modelValue" @close="closed">
    <el-form :model="from">
      <el-form-item label="充值课时数" label-width="100px">
        <el-select  v-model="sexual" placeholder="选择性别">
          <el-option label="10" value="10"></el-option>
          <el-option label="36" value="36"></el-option>
          <el-option label="150" value="150"></el-option>
        </el-select>
      <el-form-item label="学员姓名" label-width="100px">
        <el-input v-model="name"></el-input>
      </el-form-item>
      <el-form-item label="性别" label-width="100px">
        <el-select  v-model="sexual" placeholder="选择性别">
          <el-option label="男" value="男"></el-option>
          <el-option label="女" value="女"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="联系方式" label-width="100px">
        <el-input v-model="parent_tel"></el-input>
      </el-form-item>
      <el-form-item label="出生日期" label-width="100px">
        <el-input v-model="birthday"></el-input>
      </el-form-item>
      <el-form-item label="备注" label-width="100px">
        <el-input type="textarea" v-model="remark"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="closed">取 消</el-button>
      <el-button type="primary" @click="createNewUser">确 定</el-button>
    </template>
  </el-dialog>
</template>
