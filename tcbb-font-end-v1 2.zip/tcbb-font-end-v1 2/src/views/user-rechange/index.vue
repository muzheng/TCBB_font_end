<template>
  <div class="user-manage-container">
    <el-card class="header">
      <el-form inline="true">
        <el-form-item label="学员卡号" label-width="100px">
          <el-input :disabled="true" ></el-input>
        </el-form-item>
        <el-form-item label="学员姓名" label-width="100px">
          <el-input :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="当前课时总数" label-width="100px">
          <el-input :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="充值总额度" label-width="100px">
          <el-input :disabled="true"></el-input>
        </el-form-item>
        <el-button type="success">充值</el-button>
      </el-form>
    </el-card>
  </div>
  <div>
    <el-card>
      <el-table v-loading="loading" :data="tableData" stripe="true" border="true" style="width: 100%">
        <el-table-column type="index" label="#" width="80"></el-table-column>
        <el-table-column label="订单号" prop="card_number" width="120"></el-table-column>
        <el-table-column label="充值课时数" prop="name" width="120"></el-table-column>
        <el-table-column label="状态" prop="sexual" width="100"></el-table-column>
        <el-table-column label="剩余有效课时数" prop="birthday" width="120"></el-table-column>
        <el-table-column label="课程激活时间" prop="parent_tel" width="150"></el-table-column>
        <el-table-column label="总有效天数" prop="class" width="120"></el-table-column>
        <el-table-column label="剩余有效天数" prop="cost_total" width="150"></el-table-column>
        <el-table-column label="剩余可修改次数" prop="create_time" width="200"></el-table-column>
        <el-table-column label="充值时间" prop="update_time" width="200"></el-table-column>
        <el-table-column label="更新时间" prop="update_time" width="200"></el-table-column>
        <el-table-column label="操作" width="350">
          <template #default="{ row }">
            <el-button type="success" size="small" @click="onSupply(row)">修改</el-button>
            <el-button type="primary" size="small" @click="onEdit(row)">查看详情</el-button>
            <el-button type="warning" size="small" @click="onGift(row)">终止课程</el-button>
            <el-button type="danger" size="small" @click="onDelete(row)">删除</el-button>

          </template>
        </el-table-column>
      </el-table>
      <el-pagination class="pagination" @size-change="handleSizeChange"
                     @current-change="handCurrentChange"
                     :current-page="page"
                     :page-sizes="[2,5,10,20]"
                     layout="total, sizes, prev, next, jumper"
                     :total="total"
      ></el-pagination>
    </el-card>
  </div>
  <user-invest></user-invest>
</template>

<script setup>
import {} from 'vue'
import UserInvest from './components/userInvest'
</script>

<style scoped>

</style>
