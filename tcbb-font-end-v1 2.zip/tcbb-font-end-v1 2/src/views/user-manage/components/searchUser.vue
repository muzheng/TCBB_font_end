<template>
  <el-dialog title="学员信息查找" width="90%" :model-value="modelValue" @close="closed">
    <el-card class="header">
      <el-form :inline="true" label-width="200px">
        <el-form-item label="输入学员卡号">
          <el-col :span="115">
            <el-input v-model="cardID"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="small" @click="onSearchForCard()">查询</el-button>
        </el-form-item>
        <el-form-item label="输入学员姓名">
          <el-col :span="115">
            <el-input v-model="userName"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="small" @click="onSearchForName()">查询</el-button>
        </el-form-item>
        <el-form-item label="输入电话号码">
          <el-col :span="115">
            <el-input v-model="userTel"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="small" @click="onSearchForTel()">查询</el-button>
        </el-form-item>
      </el-form>
    </el-card>
    <div>
      <el-card>
        <el-table v-loading="loading" :data="tableData" stripe="true" border="true" style="width: 100%">
          <el-table-column type="index" label="#" width="80"></el-table-column>
          <el-table-column label="会员卡号" prop="card_number" width="120"></el-table-column>
          <el-table-column label="姓名" prop="name" width="120"></el-table-column>
          <el-table-column label="性别" prop="sexual" width="100"></el-table-column>
          <el-table-column label="出生日期" prop="birthday" width="120"></el-table-column>
          <el-table-column label="联系方式" prop="parent_tel" width="150"></el-table-column>
          <el-table-column label="剩余总课时数" prop="class" width="120"></el-table-column>
          <el-table-column label="充值总额（元）" prop="cost_total" width="150"></el-table-column>
          <el-table-column label="信息创建时间" prop="create_time" width="200"></el-table-column>
          <el-table-column label="信息更新时间" prop="update_time" width="200"></el-table-column>
          <el-table-column label="操作" width="350">
            <template #default="{ row }">
              <el-button type="success" size="small" @click="onSupply(row)">充值</el-button>
              <el-button type="primary" size="small" @click="onEdit(row)">编辑</el-button>
              <el-button type="warning" size="small" @click="onGift(row)">赠送</el-button>
              <el-button type="danger" size="small" @click="onDelete(row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-card>
    </div>
  </el-dialog>
</template>

<script setup>
import { defineEmits, defineProps, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { fetchByCardID, fetchByName, fetchByTel } from '@/api/user-manage'

const cardID = ref('')
const userName = ref('')
const userTel = ref('')
const tableData = ref([])
const loading = ref(false)

// 接收父组件传递的数据
const props = defineProps({
  modelValue: {
    type: Boolean,
    required: true
  }
})
console.log(props)
const emist = defineEmits(['update:modelValue'])
console.log(emist)

const closed = () => {
  emist('update:modelValue', false)
}

const onSearchForCard = () => {
  const newCardID = cardID.value
  fetchByCardID({ newCardID }).then(res => {
    console.log(res)
    console.log(res.total)
    console.log(res.list)
    const total = res.total
    if (parseInt(total) > 0) {
      loading.value = true
      tableData.value = res.list
      loading.value = false
    } else {
      ElMessage.warning('此卡号信息不存在，请重新确认')
    }
  })
}

const onSearchForName = () => {
  const newUserName = userName.value
  fetchByName({ newUserName }).then(res => {
    console.log(res)
    console.log(res.total)
    console.log(res.list)
    const total = res.total
    if (parseInt(total) > 0) {
      loading.value = true
      tableData.value = res.list
      loading.value = false
    } else {
      ElMessage.warning('此姓名信息不存在，请重新确认')
    }
  })
}

const onSearchForTel = () => {
  const newUserTel = userTel.value
  fetchByTel({ newUserTel }).then(res => {
    console.log(res)
    console.log(res.total)
    console.log(res.list)
    const total = res.total
    if (parseInt(total) > 0) {
      loading.value = true
      tableData.value = res.list
      loading.value = false
    } else {
      ElMessage.warning('此电话号码信息不存在，请重新确认')
    }
  })
}
</script>

<style lang="scss" scoped>

</style>
