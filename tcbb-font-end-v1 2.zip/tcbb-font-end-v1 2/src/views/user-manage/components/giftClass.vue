<template>
  <div class="">赠送课程</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped>

</style>
