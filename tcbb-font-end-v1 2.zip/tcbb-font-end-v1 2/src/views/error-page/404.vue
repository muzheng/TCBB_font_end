<template>
  <div class="">404</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped>

</style>
