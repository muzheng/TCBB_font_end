<template>
<div class="">问题治具提交</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped>

</style>
