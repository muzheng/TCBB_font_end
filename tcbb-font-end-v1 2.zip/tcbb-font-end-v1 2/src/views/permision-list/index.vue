<template>
<div>权限列表</div>
</template>

<script>
export default {
  name: 'index'
}
</script>

<style scoped>

</style>
