<template>
<el-dialog title="创建超级管理员" width="50%" :model-value="modelValue" @close="closed">
  <el-form :model="from">
    <el-form-item label="工号" label-width="120px">
      <el-input v-model = "superemployeenumber"></el-input>
    </el-form-item>
    <el-form-item label="姓名" label-width="120px">
      <el-input v-model = "superusername"></el-input>
    </el-form-item>
    <el-form-item label="联系方式" label-width="120px">
      <el-input v-model = "supermobile"></el-input>
    </el-form-item>
    <el-form-item label="班次" label-width="120px">
      <el-select v-model = "supershift">
        <el-option label="R" value="R"></el-option>
        <el-option label="A" value="A"></el-option>
        <el-option label="B" value="B"></el-option>
        <el-option label="C" value="C"></el-option>
        <el-option label="D" value="D"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="描述" label-width="120px">
      <el-input v-model="superdescribe"></el-input>
    </el-form-item>
    <el-upload
      class="upload-demo"
      action="http://localhost:3000/user/upload/"
      :on-preview="handlePreview"
      :on-remove="handleRemove"
      :on-success="handleSuccess"
      list-type="picture">
      <el-button size="small" type="primary">点击上传</el-button>
    </el-upload>
  </el-form>
  <template #footer>
    <el-button @click="closed">取 消</el-button>
    <el-button type="primary" @click="createNewSuperAdmin">确 定</el-button>
  </template>
</el-dialog>
</template>

<script setup>
import { ref, defineProps, defineEmits } from 'vue'
import { removeAvatar, createSuperAdmin } from '@/api/user'

const superemployeenumber = ref(null)
const superusername = ref(null)
const supermobile = ref(null)
const supershift = ref(null)
const superdescribe = ref(null)

// 接收父组件传递的数据
const props = defineProps({
  modelValue: {
    type: Boolean,
    required: true
  }
})
console.log(props)

// 将子组件参数，传入父组件
const emist = defineEmits(['update:modelValue'])
console.log(emist)

const closed = () => {
  emist('update:modelValue', false)
}

const handlePreview = (file) => {
  console.log(file)
}
console.log(handlePreview)

const handleRemove = (file) => {
  const filePath = file.response.dest
  removeAvatar({ path: filePath }).then(res => {
    console.log(res)
  })
  console.log(file.response.dest)
}

const handleSuccess = (file) => {
  console.log(file)
}

const createNewSuperAdmin = () => {
  createSuperAdmin({ superemployeenumber, superusername, supermobile, supershift, superdescribe }).then(res => {
    console.log(res)
  })
}
</script>

<style lang="scss" scoped>

</style>
