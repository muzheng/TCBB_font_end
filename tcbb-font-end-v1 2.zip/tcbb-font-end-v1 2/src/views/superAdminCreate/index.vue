<template>
  <div class="">
    <el-card>
      <el-button type="primary" @click="onCreateSuperAdmin">创建</el-button>
    </el-card>
  </div>
  <div>
    <el-card>
      <!--border style="width: 100%" 指定边框为100%-->
      <el-table  v-loading = 'loading'  border style="width: 100%">
        <el-table-column type="index"  label="序号" width="120"></el-table-column>
        <el-table-column  label="工号" prop="superemployeenumber" ></el-table-column>
        <el-table-column  label="姓名" prop="superusername"></el-table-column>
        <el-table-column  label="联系方式" prop="supermobile"></el-table-column>
        <el-table-column  label="班次" prop="supershift"></el-table-column>
        <el-table-column  label="描述" prop="superdescribe"></el-table-column>
        <el-table-column  label="操作" width="200">
          <el-button type="primary" size="mini">编辑</el-button>
          <el-button type="danger" size="mini">删除</el-button>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
  <create-super-admin v-model = "createSuperAdminDialogVisable"></create-super-admin>
</template>

<script setup>
import { ref, watch } from 'vue'
import createSuperAdmin from './components/createSuperAdmin'

const createSuperAdminDialogVisable = ref(false)

const onCreateSuperAdmin = () => {
  createSuperAdminDialogVisable.value = true
}

watch(createSuperAdminDialogVisable, val => {
  console.log(val)
})
</script>

<style lang="scss" scoped>

</style>
