/**
 * state: 驱动应用的数据源
 * acttions: 活动
 * mutations: 非常类似于事件，每个 mutations 都有一个字符串的事件类型(type)和一个回调函数(handler)，也可以理解为{type:handler()}，
 * Vuex 规定必须使用 store.commit 来触发对应 type 的方法
 * eg: store.commit('increment')
 */
import { createStore } from 'vuex'
import user from './modules/user'
// 处理左侧菜单动态
import app from './modules/app'
import getters from './getters'
/**
export default createStore({
  state: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
 */

/**
 * 完成模块注册 注册user
 *
 */
export default createStore({
  getters,
  modules: {
    user,
    app
  }
})
